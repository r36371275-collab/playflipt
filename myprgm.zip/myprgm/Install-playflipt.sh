#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
USER_HOME="$(getent passwd "$(id -un)" | cut -d: -f6)"
DATA_HOME="${XDG_DATA_HOME:-$USER_HOME/.local/share}"
APPS_DIR="$DATA_HOME/applications"
MIME_DIR="$DATA_HOME/mime/packages"
APP_DIR="$DATA_HOME/betterpet-player"
DESKTOP_DIR="$USER_HOME/Desktop"
NODE_BIN="$(command -v node || true)"

if [[ -z "$NODE_BIN" ]]; then
  echo 'Node.js не найден. Установи его командой: sudo pacman -S nodejs'
  read -r -p 'Нажми Enter, чтобы закрыть окно.' _
  exit 1
fi
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo 'ffmpeg не найден. Установи его командой: sudo pacman -S ffmpeg'
  read -r -p 'Нажми Enter, чтобы закрыть окно.' _
  exit 1
fi
if [[ ! -f "$SCRIPT_DIR/payload/default-animation/meta.txt" || ! -f "$SCRIPT_DIR/payload/default-animation/frame_0.bm" ]]; then
  echo 'В пакете установщика нет встроенной анимации.'
  echo 'Проверь, что рядом с Install-Better-Pet.sh находится папка payload/default-animation.'
  read -r -p 'Нажми Enter, чтобы закрыть окно.' _
  exit 1
fi

mkdir -p "$APP_DIR" "$APPS_DIR" "$MIME_DIR" "$DESKTOP_DIR"
install -m 755 "$SCRIPT_DIR/payload/player.js" "$APP_DIR/player.js"
install -m 644 "$SCRIPT_DIR/payload/heatshrink-ts.umd.js" "$APP_DIR/heatshrink-ts.umd.js"
install -m 644 "$SCRIPT_DIR/payload/LICENSE-heatshrink-ts.txt" "$APP_DIR/LICENSE-heatshrink-ts.txt"
rm -rf "$APP_DIR/default-animation"
mkdir -p "$APP_DIR/default-animation"
cp -a "$SCRIPT_DIR/payload/default-animation/." "$APP_DIR/default-animation/"

cat > "$MIME_DIR/betterpet-bitmap.xml" <<'MIME'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="image/x-flipper-bitmap">
    <comment>Flipper Zero bitmap animation frame</comment>
    <glob pattern="*.bm"/>
  </mime-type>
</mime-info>
MIME

# Quote paths in desktop-entry syntax so directories containing spaces still work.
desktop_quote() {
  local value="${1//\\/\\\\}"
  value="${value//\"/\\\"}"
  printf '"%s"' "$value"
}

cat > "$APPS_DIR/betterpet-bitmap-viewer.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Better-Pet Animation Player
GenericName=Flipper bitmap animation player
Comment=Play .bm animation files on this computer
Exec=$(desktop_quote "$NODE_BIN") $(desktop_quote "$APP_DIR/player.js") %f
Terminal=false
MimeType=image/x-flipper-bitmap;
Categories=Graphics;Utility;
DESKTOP

PLAYER="$(desktop_quote "$NODE_BIN") $(desktop_quote "$APP_DIR/player.js")"
cat > "$DESKTOP_DIR/Play-Better-Pet.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Better-Pet: 3D Printing
Comment=Play the orange-background animation in a dark Flipper-style case
Exec=$PLAYER
Terminal=false
Categories=Graphics;Utility;
DESKTOP
chmod +x "$DESKTOP_DIR/Play-Better-Pet.desktop"

update-mime-database "$DATA_HOME/mime"
update-desktop-database "$APPS_DIR"
xdg-mime default betterpet-bitmap-viewer.desktop image/x-flipper-bitmap

printf '\nУстановка завершена. Дважды щёлкни по frame_0.bm, чтобы проиграть анимацию.\n'
printf 'Ярлык запуска: %s\n' "$DESKTOP_DIR/Play-Better-Pet.desktop"
read -r -p 'Нажми Enter, чтобы закрыть окно.' _
