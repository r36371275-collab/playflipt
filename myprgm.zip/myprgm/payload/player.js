#!/usr/bin/node
'use strict';
const fs=require('fs'),path=require('path'),os=require('os'),{spawn}=require('child_process');
const {HeatshrinkDecoder}=require('./heatshrink-ts.umd.js');const input=process.argv[2]||path.join(__dirname,'default-animation','frame_0.bm');
function fail(msg){console.error(msg);const z=spawn('zenity',['--error','--title=Better-Pet Animation Player','--text='+msg],{stdio:'ignore',detached:true});z.unref();process.exit(1)}
if(!input)fail('Щёлкни дважды по кадру .bm, чтобы открыть его анимацию.');
const dir=path.dirname(path.resolve(input)),base=path.basename(input),metaPath=path.join(dir,'meta.txt');let meta={};
if(fs.existsSync(metaPath))for(const line of fs.readFileSync(metaPath,'utf8').split(/\r?\n/)){const m=line.match(/^([^:]+):\s*(.*)$/);if(m)meta[m[1].trim()]=m[2].trim()}
const width=Number(meta.Width)||128,height=Number(meta.Height)||64,fps=Math.max(1,Math.min(12,Number(meta['Frame rate'])||2));let names=[];
if(meta['Frames order'])names=meta['Frames order'].trim().split(/\s+/).filter(Boolean).map(n=>'frame_'+n+'.bm');
else if(/^frame_\d+\.bm$/.test(base))names=fs.readdirSync(dir).filter(n=>/^frame_\d+\.bm$/.test(n)).sort((a,b)=>Number(a.match(/\d+/)[0])-Number(b.match(/\d+/)[0]));else names=[base];if(!names.length)names=[base];
function decode(file){const raw=fs.readFileSync(path.join(dir,file));let pixels;if(raw[0]){if(raw.length<4)throw Error('Неполный заголовок '+file);const size=raw.readUInt16LE(2);if(size>raw.length-4)throw Error('Повреждённый кадр '+file);const d=new HeatshrinkDecoder(8,4,64);d.process(new Uint8Array(raw.subarray(4,4+size)));pixels=Buffer.from(d.getOutput())}else pixels=raw.subarray(1);const need=Math.ceil(width/8)*height;if(pixels.length<need)throw Error('Не удалось распаковать кадр '+file);return pixels}
let frames;try{frames=names.map(decode)}catch(e){fail(e.message)}
const W=320,H=600,safe=path.basename(dir).replace(/[^a-z0-9_-]+/gi,'_'),out=path.join(os.tmpdir(),'betterpet-flipper-'+safe+'-'+Date.now()+'.gif');
const ff=spawn('/usr/bin/ffmpeg',['-hide_banner','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',W+'x'+H,'-framerate',String(fps),'-i','pipe:0','-filter_complex','[0:v]split[a][b];[a]palettegen=max_colors=16[p];[b][p]paletteuse=dither=none','-loop','0','-y',out],{stdio:['pipe','ignore','pipe']});let errors='';ff.stderr.on('data',d=>errors+=d.toString());ff.on('error',e=>fail('Не удалось запустить ffmpeg: '+e.message));
ff.on('close',code=>{if(code!==0)fail(errors||'ffmpeg завершился с ошибкой');if(process.env.BETTERPET_NO_OPEN==='1'){console.log(out);return}const opener=spawn('xdg-open',[out],{detached:true,stdio:'ignore'});opener.on('error',e=>fail('GIF создан: '+out+'\nНе получилось открыть просмотрщик: '+e.message));opener.unref()});
function rgb(r,g,b){return [r,g,b]}
function rect(buf,x,y,w,h,c){for(let yy=Math.max(0,y);yy<Math.min(H,y+h);yy++)for(let xx=Math.max(0,x);xx<Math.min(W,x+w);xx++){let k=(yy*W+xx)*3;buf[k]=c[0];buf[k+1]=c[1];buf[k+2]=c[2]}}
function roundRect(buf,x,y,w,h,r,c){for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++){let cx=xx<x+r?x+r:xx>=x+w-r?x+w-r-1:xx,cy=yy<y+r?y+r:yy>=y+h-r?y+h-r-1:yy,dx=xx-cx,dy=yy-cy;if(xx<0||xx>=W||yy<0||yy>=H||dx*dx+dy*dy>r*r)continue;let k=(yy*W+xx)*3;buf[k]=c[0];buf[k+1]=c[1];buf[k+2]=c[2]}}
function circle(buf,cx,cy,r,c){for(let y=cy-r;y<=cy+r;y++)for(let x=cx-r;x<=cx+r;x++)if((x-cx)**2+(y-cy)**2<=r*r){let k=(y*W+x)*3;buf[k]=c[0];buf[k+1]=c[1];buf[k+2]=c[2]}}
function triangle(buf,pts,c){const [a,b,cpt]=pts;let minX=Math.min(a[0],b[0],cpt[0]),maxX=Math.max(a[0],b[0],cpt[0]),minY=Math.min(a[1],b[1],cpt[1]),maxY=Math.max(a[1],b[1],cpt[1]);const cross=(p1,p2,x,y)=>(x-p2[0])*(p1[1]-p2[1])-(p1[0]-p2[0])*(y-p2[1]);for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){let d1=cross(a,b,x,y),d2=cross(b,cpt,x,y),d3=cross(cpt,a,x,y);if((d1>=0&&d2>=0&&d3>=0)||(d1<=0&&d2<=0&&d3<=0)){let k=(y*W+x)*3;buf[k]=c[0];buf[k+1]=c[1];buf[k+2]=c[2]}}}
function makeFrame(bits){const buf=Buffer.alloc(W*H*3);rect(buf,0,0,W,H,rgb(235,112,18));roundRect(buf,24,17,272,566,42,rgb(3,4,6));roundRect(buf,30,20,260,557,38,rgb(34,37,42));roundRect(buf,35,24,250,548,34,rgb(22,25,30));
// display bezel and glass
roundRect(buf,50,58,220,128,20,rgb(10,12,16));roundRect(buf,54,62,212,120,17,rgb(8,10,12));roundRect(buf,62,70,196,104,9,rgb(5,3,1));
// bitmap rendered with nearest-neighbour pixels
const sx=70,sy=74,sw=180,sh=90,stride=Math.ceil(width/8),mask=new Uint8Array(sw*sh);for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){const px=Math.floor(x*width/sw),py=Math.floor(y*height/sh);mask[y*sw+x]=(bits[py*stride+(px>>3)]>>(px&7))&1}for(let y=0;y<sh;y++)for(let x=0;x<sw;x++){let distance=99;for(let dy=-3;dy<=3;dy++)for(let dx=-3;dx<=3;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&xx<sw&&yy>=0&&yy<sh&&mask[yy*sw+xx])distance=Math.min(distance,Math.abs(dx)+Math.abs(dy))}let color;if(mask[y*sw+x])color=[255,143,38];else if(distance===1)color=[136,54,7];else if(distance===2)color=[75,28,3];else if(distance===3)color=[38,14,1];else continue;const k=((sy+y)*W+sx+x)*3;buf[k]=color[0];buf[k+1]=color[1];buf[k+2]=color[2]}
// controls: two utility keys, directional pad, select/back buttons
circle(buf,91,235,25,rgb(190,82,16));circle(buf,91,232,18,rgb(43,47,53));circle(buf,229,235,25,rgb(190,82,16));circle(buf,229,232,18,rgb(43,47,53));
roundRect(buf,144,293,32,128,9,rgb(179,75,13));roundRect(buf,96,341,128,32,9,rgb(179,75,13));roundRect(buf,150,299,20,116,7,rgb(56,61,68));roundRect(buf,102,347,116,20,7,rgb(56,61,68));
triangle(buf,[[160,305],[153,318],[167,318]],rgb(239,125,22));triangle(buf,[[160,409],[153,396],[167,396]],rgb(239,125,22));triangle(buf,[[102,357],[115,350],[115,364]],rgb(239,125,22));triangle(buf,[[218,357],[205,350],[205,364]],rgb(239,125,22));
circle(buf,105,482,20,rgb(179,75,13));circle(buf,105,479,13,rgb(43,47,53));circle(buf,215,482,20,rgb(179,75,13));circle(buf,215,479,13,rgb(43,47,53));
// small speaker slots and indicator
for(let i=0;i<7;i++)roundRect(buf,117+i*14,528,8,3,1,rgb(91,49,23));circle(buf,160,45,3,rgb(255,161,54));return buf}
for(const frame of frames)ff.stdin.write(makeFrame(frame));ff.stdin.end();
